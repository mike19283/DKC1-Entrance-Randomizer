﻿namespace DKC_Stage_Randomizer
{
    partial class DKC_Stage_Randomizer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {

            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DKC_Stage_Randomizer));
            this.button_randomize = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.radioButton_notValid = new System.Windows.Forms.RadioButton();
            this.radioButton_valid = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_seedEnter = new System.Windows.Forms.TextBox();
            this.button_seedEnter = new System.Windows.Forms.Button();
            this.panel_hud = new System.Windows.Forms.Panel();
            this.checkBox_devSpoil = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.checkBox_randomizeROM = new System.Windows.Forms.CheckBox();
            this.checkBox_animalCarryover = new System.Windows.Forms.CheckBox();
            this.checkBox_randomizeAnimals = new System.Windows.Forms.CheckBox();
            this.checkBox_enemies = new System.Windows.Forms.CheckBox();
            this.checkBox_bosses = new System.Windows.Forms.CheckBox();
            this.checkBox_godAwfulMusic = new System.Windows.Forms.CheckBox();
            this.checkBox_music = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox_color = new System.Windows.Forms.ComboBox();
            this.checkBox_gravity = new System.Windows.Forms.CheckBox();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.button_fullyRandomize = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.panel_hud.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_randomize
            // 
            this.button_randomize.Location = new System.Drawing.Point(392, 185);
            this.button_randomize.Name = "button_randomize";
            this.button_randomize.Size = new System.Drawing.Size(75, 23);
            this.button_randomize.TabIndex = 0;
            this.button_randomize.Text = "Randomize!";
            this.button_randomize.UseVisualStyleBackColor = true;
            this.button_randomize.Click += new System.EventHandler(this.button_randomize_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Moonbeam", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(256, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(309, 39);
            this.label1.TabIndex = 1;
            this.label1.Text = "Entrance Randomizer";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.radioButton_notValid);
            this.groupBox2.Controls.Add(this.radioButton_valid);
            this.groupBox2.Location = new System.Drawing.Point(12, 50);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(330, 118);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Logic";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(207, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 39);
            this.label2.TabIndex = 6;
            this.label2.Text = "WARNING - May\r\nmake impossible!\r\nNot friendly for races";
            // 
            // radioButton_notValid
            // 
            this.radioButton_notValid.AutoSize = true;
            this.radioButton_notValid.Location = new System.Drawing.Point(210, 42);
            this.radioButton_notValid.Name = "radioButton_notValid";
            this.radioButton_notValid.Size = new System.Drawing.Size(64, 17);
            this.radioButton_notValid.TabIndex = 5;
            this.radioButton_notValid.TabStop = true;
            this.radioButton_notValid.Text = "No logic";
            this.toolTip1.SetToolTip(this.radioButton_notValid, "Doesn\'t make sure the seed is completable.\r\nAnything goes");
            this.radioButton_notValid.UseVisualStyleBackColor = true;
            // 
            // radioButton_valid
            // 
            this.radioButton_valid.AutoSize = true;
            this.radioButton_valid.Checked = true;
            this.radioButton_valid.Location = new System.Drawing.Point(35, 42);
            this.radioButton_valid.Name = "radioButton_valid";
            this.radioButton_valid.Size = new System.Drawing.Size(51, 17);
            this.radioButton_valid.TabIndex = 3;
            this.radioButton_valid.TabStop = true;
            this.radioButton_valid.Text = "Logic";
            this.toolTip1.SetToolTip(this.radioButton_valid, "Makes sure the seed is completable.\r\nUse for race settings");
            this.radioButton_valid.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(357, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Enter custom seed (optional)\r\n";
            // 
            // textBox_seedEnter
            // 
            this.textBox_seedEnter.Location = new System.Drawing.Point(377, 104);
            this.textBox_seedEnter.Name = "textBox_seedEnter";
            this.textBox_seedEnter.Size = new System.Drawing.Size(100, 20);
            this.textBox_seedEnter.TabIndex = 8;
            this.toolTip1.SetToolTip(this.textBox_seedEnter, "Enter in a custom seed with whatever flags desired");
            // 
            // button_seedEnter
            // 
            this.button_seedEnter.Location = new System.Drawing.Point(392, 141);
            this.button_seedEnter.Name = "button_seedEnter";
            this.button_seedEnter.Size = new System.Drawing.Size(75, 23);
            this.button_seedEnter.TabIndex = 9;
            this.button_seedEnter.Text = "Confirm";
            this.button_seedEnter.UseVisualStyleBackColor = true;
            this.button_seedEnter.Click += new System.EventHandler(this.button_seedEnter_Click);
            // 
            // panel_hud
            // 
            this.panel_hud.Controls.Add(this.button_fullyRandomize);
            this.panel_hud.Controls.Add(this.checkBox_devSpoil);
            this.panel_hud.Controls.Add(this.label4);
            this.panel_hud.Controls.Add(this.pictureBox1);
            this.panel_hud.Controls.Add(this.checkBox_randomizeROM);
            this.panel_hud.Controls.Add(this.checkBox_animalCarryover);
            this.panel_hud.Controls.Add(this.checkBox_randomizeAnimals);
            this.panel_hud.Controls.Add(this.checkBox_enemies);
            this.panel_hud.Controls.Add(this.checkBox_bosses);
            this.panel_hud.Controls.Add(this.checkBox_godAwfulMusic);
            this.panel_hud.Controls.Add(this.checkBox_music);
            this.panel_hud.Controls.Add(this.groupBox1);
            this.panel_hud.Controls.Add(this.checkBox_gravity);
            this.panel_hud.Controls.Add(this.button_randomize);
            this.panel_hud.Controls.Add(this.button_seedEnter);
            this.panel_hud.Controls.Add(this.label1);
            this.panel_hud.Controls.Add(this.textBox_seedEnter);
            this.panel_hud.Controls.Add(this.label3);
            this.panel_hud.Controls.Add(this.groupBox2);
            this.panel_hud.Location = new System.Drawing.Point(-6, 34);
            this.panel_hud.Name = "panel_hud";
            this.panel_hud.Size = new System.Drawing.Size(945, 281);
            this.panel_hud.TabIndex = 10;
            this.panel_hud.Visible = false;
            // 
            // checkBox_devSpoil
            // 
            this.checkBox_devSpoil.AutoSize = true;
            this.checkBox_devSpoil.Location = new System.Drawing.Point(792, 221);
            this.checkBox_devSpoil.Name = "checkBox_devSpoil";
            this.checkBox_devSpoil.Size = new System.Drawing.Size(101, 17);
            this.checkBox_devSpoil.TabIndex = 24;
            this.checkBox_devSpoil.Text = "Dev sspoiler log";
            this.checkBox_devSpoil.UseVisualStyleBackColor = true;
            this.checkBox_devSpoil.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(499, 182);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 26);
            this.label4.TabIndex = 23;
            this.label4.Text = "Click this picture of \r\nCandy for no reason";
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(606, 162);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(46, 110);
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // checkBox_randomizeROM
            // 
            this.checkBox_randomizeROM.AutoSize = true;
            this.checkBox_randomizeROM.Checked = true;
            this.checkBox_randomizeROM.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_randomizeROM.Location = new System.Drawing.Point(233, 234);
            this.checkBox_randomizeROM.Name = "checkBox_randomizeROM";
            this.checkBox_randomizeROM.Size = new System.Drawing.Size(107, 17);
            this.checkBox_randomizeROM.TabIndex = 21;
            this.checkBox_randomizeROM.Text = "Randomize ROM";
            this.checkBox_randomizeROM.UseVisualStyleBackColor = true;
            // 
            // checkBox_animalCarryover
            // 
            this.checkBox_animalCarryover.AutoSize = true;
            this.checkBox_animalCarryover.Enabled = false;
            this.checkBox_animalCarryover.Location = new System.Drawing.Point(47, 209);
            this.checkBox_animalCarryover.Name = "checkBox_animalCarryover";
            this.checkBox_animalCarryover.Size = new System.Drawing.Size(104, 30);
            this.checkBox_animalCarryover.TabIndex = 20;
            this.checkBox_animalCarryover.Text = "Occasional\r\nAnimal carryover";
            this.toolTip1.SetToolTip(this.checkBox_animalCarryover, "Allow buddies to be taken from stage to stage (sometimes)");
            this.checkBox_animalCarryover.UseVisualStyleBackColor = true;
            this.checkBox_animalCarryover.Visible = false;
            // 
            // checkBox_randomizeAnimals
            // 
            this.checkBox_randomizeAnimals.AutoSize = true;
            this.checkBox_randomizeAnimals.Location = new System.Drawing.Point(647, 139);
            this.checkBox_randomizeAnimals.Name = "checkBox_randomizeAnimals";
            this.checkBox_randomizeAnimals.Size = new System.Drawing.Size(97, 17);
            this.checkBox_randomizeAnimals.TabIndex = 19;
            this.checkBox_randomizeAnimals.Text = "Animal buddies";
            this.toolTip1.SetToolTip(this.checkBox_randomizeAnimals, "Randomize animal buddies dynamically (not water)");
            this.checkBox_randomizeAnimals.UseVisualStyleBackColor = true;
            // 
            // checkBox_enemies
            // 
            this.checkBox_enemies.AutoSize = true;
            this.checkBox_enemies.Location = new System.Drawing.Point(647, 109);
            this.checkBox_enemies.Name = "checkBox_enemies";
            this.checkBox_enemies.Size = new System.Drawing.Size(66, 17);
            this.checkBox_enemies.TabIndex = 18;
            this.checkBox_enemies.Text = "Enemies";
            this.toolTip1.SetToolTip(this.checkBox_enemies, "Randomizes enemies dynamically");
            this.checkBox_enemies.UseVisualStyleBackColor = true;
            // 
            // checkBox_bosses
            // 
            this.checkBox_bosses.AutoSize = true;
            this.checkBox_bosses.Location = new System.Drawing.Point(647, 79);
            this.checkBox_bosses.Name = "checkBox_bosses";
            this.checkBox_bosses.Size = new System.Drawing.Size(60, 17);
            this.checkBox_bosses.TabIndex = 17;
            this.checkBox_bosses.Text = "Bosses";
            this.toolTip1.SetToolTip(this.checkBox_bosses, "Randomizes bosses (what happens in them)");
            this.checkBox_bosses.UseVisualStyleBackColor = true;
            // 
            // checkBox_godAwfulMusic
            // 
            this.checkBox_godAwfulMusic.AutoSize = true;
            this.checkBox_godAwfulMusic.Location = new System.Drawing.Point(519, 139);
            this.checkBox_godAwfulMusic.Name = "checkBox_godAwfulMusic";
            this.checkBox_godAwfulMusic.Size = new System.Drawing.Size(105, 17);
            this.checkBox_godAwfulMusic.TabIndex = 16;
            this.checkBox_godAwfulMusic.Text = "God Awful music";
            this.toolTip1.SetToolTip(this.checkBox_godAwfulMusic, "Music Donkey listens to");
            this.checkBox_godAwfulMusic.UseVisualStyleBackColor = true;
            this.checkBox_godAwfulMusic.CheckedChanged += new System.EventHandler(this.checkBox_godAwfulMusic_CheckedChanged);
            // 
            // checkBox_music
            // 
            this.checkBox_music.AutoSize = true;
            this.checkBox_music.Location = new System.Drawing.Point(519, 109);
            this.checkBox_music.Name = "checkBox_music";
            this.checkBox_music.Size = new System.Drawing.Size(54, 17);
            this.checkBox_music.TabIndex = 15;
            this.checkBox_music.Text = "Music";
            this.toolTip1.SetToolTip(this.checkBox_music, "Randomize music for each stage");
            this.checkBox_music.UseVisualStyleBackColor = true;
            this.checkBox_music.CheckedChanged += new System.EventHandler(this.checkBox_music_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBox_color);
            this.groupBox1.Location = new System.Drawing.Point(755, 92);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(172, 76);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Color";
            // 
            // comboBox_color
            // 
            this.comboBox_color.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_color.FormattingEnabled = true;
            this.comboBox_color.Items.AddRange(new object[] {
            "Red",
            "Teal",
            "Purple",
            "Green",
            "White",
            "Yellow",
            "Orange",
            "Albino",
            "Ghost",
            "Random"});
            this.comboBox_color.Location = new System.Drawing.Point(20, 27);
            this.comboBox_color.Name = "comboBox_color";
            this.comboBox_color.Size = new System.Drawing.Size(121, 21);
            this.comboBox_color.TabIndex = 18;
            this.toolTip1.SetToolTip(this.comboBox_color, "Select color");
            this.comboBox_color.SelectedIndexChanged += new System.EventHandler(this.comboBox_color_SelectedIndexChanged);
            // 
            // checkBox_gravity
            // 
            this.checkBox_gravity.AutoSize = true;
            this.checkBox_gravity.Location = new System.Drawing.Point(519, 79);
            this.checkBox_gravity.Name = "checkBox_gravity";
            this.checkBox_gravity.Size = new System.Drawing.Size(80, 17);
            this.checkBox_gravity.TabIndex = 13;
            this.checkBox_gravity.Text = "Low gravity";
            this.toolTip1.SetToolTip(this.checkBox_gravity, "Makes Kongs jump like there is low gravity (not truly\r\nlow gravity)");
            this.checkBox_gravity.UseVisualStyleBackColor = true;
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(933, 24);
            this.menuStrip2.TabIndex = 11;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadToolStripMenuItem,
            this.aboutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.loadToolStripMenuItem.Text = "Load";
            this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // button_fullyRandomize
            // 
            this.button_fullyRandomize.Location = new System.Drawing.Point(392, 224);
            this.button_fullyRandomize.Name = "button_fullyRandomize";
            this.button_fullyRandomize.Size = new System.Drawing.Size(75, 34);
            this.button_fullyRandomize.TabIndex = 25;
            this.button_fullyRandomize.Text = "Fully randomize!";
            this.toolTip1.SetToolTip(this.button_fullyRandomize, "Randomizes options too (including logic)");
            this.button_fullyRandomize.UseVisualStyleBackColor = true;
            this.button_fullyRandomize.Click += new System.EventHandler(this.button_fullyRandomize_Click);
            // 
            // DKC_Stage_Randomizer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 314);
            this.Controls.Add(this.panel_hud);
            this.Controls.Add(this.menuStrip2);
            this.Name = "DKC_Stage_Randomizer";
            this.Text = "DKC Entrance Randomizer";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel_hud.ResumeLayout(false);
            this.panel_hud.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_randomize;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton radioButton_notValid;
        private System.Windows.Forms.RadioButton radioButton_valid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_seedEnter;
        private System.Windows.Forms.Button button_seedEnter;
        private System.Windows.Forms.Panel panel_hud;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.CheckBox checkBox_gravity;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox_bosses;
        private System.Windows.Forms.CheckBox checkBox_godAwfulMusic;
        private System.Windows.Forms.CheckBox checkBox_music;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ComboBox comboBox_color;
        private System.Windows.Forms.CheckBox checkBox_enemies;
        private System.Windows.Forms.CheckBox checkBox_animalCarryover;
        private System.Windows.Forms.CheckBox checkBox_randomizeAnimals;
        private System.Windows.Forms.CheckBox checkBox_randomizeROM;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkBox_devSpoil;
        private System.Windows.Forms.Button button_fullyRandomize;
    }
}

