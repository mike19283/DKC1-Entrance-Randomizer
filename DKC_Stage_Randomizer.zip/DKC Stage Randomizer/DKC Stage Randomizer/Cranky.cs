﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DKC_Stage_Randomizer;

namespace DKC_Entrance_Randomizer
{
    public partial class Cranky
    {
        private String[] hintList;
        private int bonusLeads = 0;
        private int exitLeads = 0;
        // Index 0, named3e
        // Index 1, exitType
        private List<String> bosse0 = new List<String>();
        private List<String> bosse1 = new List<String>();
        private List<String> bosse3 = new List<String>();
        private List<String> bosse5 = new List<String>();
        private List<String> boss68 = new List<String>();
        private List<String> listOfGreetings = new List<String>();
        private List<List<String>> bossList;

        public Cranky()
        {
            bossList = new List<List<String>>() { bosse0, bosse1, bosse3, bosse5, boss68 };
            AddPrevious(bosse0, bosse1, bosse3, bosse5, boss68);
            CountTypes(bosse0, bosse1, bosse3, bosse5, boss68);

            ApplyRandomText();
/*
            var x = GenerateRandomHints();

            foreach (var y in x)
                MessageBox.Show(y);
*/
        }


        // Lookup variable boss location (not where it should be)
        private byte LookupLocation (byte code)
        {
            byte codeToReturn = 0;
            // 0xa6c50 is where my LUT in ROM is
            // Loop through LUT and find code
            for (int i = 0xa6c50; i < 0xa6c50 + 0x100; i++)
            {
                if (Global.data[i] == code && i - 0xa6c50 != code)
                {
                    codeToReturn = (byte)(i - 0xa6c50);
                    break;
                }              
            }

            return codeToReturn;
        }
        // Add both previous
        // Add previous exits and types
        private void AddPrevious(params List<String>[] previous)
        {
            byte[] exitCodes = new byte[] { 0xe0, 0xe1, 0xe3, 0xe5, 0x68 };
            // Add to each
            for (int i = 0; i < exitCodes.Length; i++)
            {
                previous[i].Add(named3eCodes[LookupLocation(exitCodes[i])]);
                previous[i].Add(exitType[LookupLocation(exitCodes[i])]);
            }

        }
        // Count up bonuses versus not
        private void CountTypes(params List<String>[] previous)
        {
            // Loop through each passed list
            foreach (var prev in previous)
            {
                // Are we taking a bonus?
                if (prev[0].Contains(" - Bonus"))
                    bonusLeads++;
                // Are we taking an exit?
                if (prev[0].Contains("level"))
                    exitLeads++;
            }
        }
        // Write string to ROM
        public void ApplyRandomText ()
        {
            // P A R T 1
            // Set up our List of greetings
            var tempGreeting = GetRandomGreeting();
            // Loop through our greetings
            for (int i = 0; i < tempGreeting.Count; i++)
            {

                List<byte> bytesToCopy = new List<byte>();
                // Split greeting into a managable list of lines.
                List<String> listOfLines = ArrangeStrings(tempGreeting[i]);
                // Loop through each line
                for (int j = 0; j < listOfLines.Count; j++)
                {
                    // Get array of string as bytes
                    List<byte> bytes = Encoding.ASCII.GetBytes(listOfLines[j]).ToList();
                    bytes.Add(0xa0);
                    // Did we reach the last string?
                    if (j == listOfLines.Count - 1)
                        bytes.Add(0x00);

                    bytesToCopy.AddRange(bytes);
                }
                // Copy whole list to ROM
                Global.ApplyEdits(addressOfGreetings[i], bytesToCopy.ToArray());


            }

            // P A R T 2
            // Set up our List of hints
            var tempHints = GenerateRandomHints();
            hintList = tempHints.ToArray();
            // Loop through our hints
            for (int i = 0; i < tempHints.Count; i++)
            {

                List<byte> bytesToCopy = new List<byte>();
                // Split hint into a managable list of lines.
                List<String> listOfLines = ArrangeStrings(tempHints[i]);
                // Loop through each line
                for (int j = 0; j < listOfLines.Count; j++)
                {
                    // Get array of string as bytes
                    List<byte> bytes = Encoding.ASCII.GetBytes(listOfLines[j]).ToList();
                    bytes.Add(0xa0);
                    // Did we reach the last string?
                    if (j == listOfLines.Count - 1)
                        bytes.Add(0x00);

                    bytesToCopy.AddRange(bytes);
                }
                // Copy whole list to ROM
                Global.ApplyEdits(addressOfHint[i], bytesToCopy.ToArray());
            }
        }
        public String[] GetHintList() => hintList;
    }
}
