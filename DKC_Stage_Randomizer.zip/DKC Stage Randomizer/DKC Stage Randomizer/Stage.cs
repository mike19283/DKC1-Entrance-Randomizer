﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKC_Stage_Randomizer
{
    public class Stage
    {
        private List<byte> entranceCodes = new List<byte>();

        public Stage()
        {

        }

    }
}
