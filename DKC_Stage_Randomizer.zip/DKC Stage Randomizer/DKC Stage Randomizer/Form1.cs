﻿using DKC_Entrance_Randomizer;
using DKC_Randomizer_V2._0;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DKC_Stage_Randomizer
{
    public partial class DKC_Stage_Randomizer : Form
    {
        //Version
        String stringVersion = "Version - 1.021";
        bool warning = false;

        public DKC_Stage_Randomizer()
        {
            InitializeComponent();
            this.Text = $"DKC Entrance Randomizer {stringVersion} ";
        }
        // Index of combobox
        int currentMyComboBoxIndex = 0;
        // Seed
        int seed;
        // Gravity rom addresses
        //	.def	DkGravity				0xbfb964
        //	.def DiddyGravity				0xbfb96c
        //  .def AnimalGravity              0xbfba14  
        String about = "****************************************\n* ENTRANCE *\n* RANDOMIZER *\n****************************************\n \nMay 7th, 2019\nThis is a program by RainbowSprinklez with pretty significant help from\nMyself086. This hack was primarily coded in ASM with a private tool and\nhas a backbone of C#. The core concept of this was by Myself086. This\ntook a few months to make. Any questions feel free to reach out to\nRainbowSprinklez or Myself086.\n\nAll trademarks held by Nintendo and Rare\n\nEmail:\nmikemingrone@gmail.com - RainbowSprinklez\n";

        // ==========================================================
        private byte[] entranceCodes = new byte[] { 0x34, 0x17, 0x76, 0x77, 0x19, 0x41, 0x92, 0x93, 0x45, 0x7, 0x78, 0x79, 0x15, 0x10, 0x3, 0xde, 0xdf, 0xbf, 0xc0, 0x3e, 0x3f, 0x18, 0x7d, 0x7e, 0x7f, 0x23, 0xd0, 0xdd, 0xdb, 0xd1, 0xa7, 0xac, 0xad, 0xa8, 0x16, 0x0, 0x8, 0x6e, 0x5f, 0xe, 0x25, 0x47, 0x4c, 0x5c, 0x36, 0x84, 0x85, 0x3d, 0x12, 0x7a, 0x7c, 0x7b, 0x29, 0x99, 0x42, 0xae, 0xaf, 0xb0, 0x58, 0x35, 0x2e, 0x38, 0xcc, 0x27, 0x8c, 0x8d, 0x8e, 0x3b, 0xa, 0x80, 0x81, 0x2d, 0x40, 0x8f, 0x90, 0x91, 0x44, 0xd, 0x73, 0x72, 0x74, 0x71, 0x75, 0x1d, 0x2b, 0x86, 0x87, 0x2c, 0x22, 0x2a, 0x1, 0xc9, 0xb, 0x26, 0x9, 0xce, 0xd8, 0xd6, 0xcf, 0xc, 0x6f, 0x70, 0xf, 0x6d, 0x62, 0xc7, 0xc8, 0xcb, 0xab, 0x24, 0x94, 0x95, 0x96, 0x28, 0x31, 0xcd, 0x82, 0x83, 0x3c, 0x30, 0x8b, 0x3a, 0x43, 0xb1, 0xb2, 0x59, 0x14, 0xc2, 0xc4, 0x13, 0xa4, 0x54, 0xb5, 0xb6, 0xa9, 0x2f, 0xbd, 0x88, 0x8a, 0x89, 0x39, 0xa5, 0x65, 0xba, 0xbb, 0xbc, 0xaa, 0xd9, 0x51, 0xda };
        // ==========================================================
        //List<bool> kkrFound = new List<bool>();
        String fileName;
        String stringSeed;
        // Address where seed text starts
        Int32 addressSeed = 0x13e1f3;
        // Version address
        Int32 addressVersion = 0x13e1a9;
        // Flags
        String staticFlags = "";
        String variableFlags = "";

        String fileRegex = "(?i)^(1?\\d{1,4})$";
        String colorOrder = "rtpgwyoas";

        String[] helpFile = new String[] { "// ====================================================", "// ===================AVAILABLE EXITS==================", "// ====================================================", "", "Enguarde bonus", "Expresso bonus", "Rambi bonus", "Winky bonus", "", "Barrel Cannon Canyon", "Barrel Cannon Canyon - Bonus 1", "Barrel Cannon Canyon - Bonus 2", "Blackout Basement", "Blackout Basement - Bonus 1", "Blackout Basement - Bonus 2", "Bouncy Bonanza", "Bouncy Bonanza - Bonus 1", "Bouncy Bonanza - Bonus 2", "Bouncy Bonanza - Winky Room", "Candy", "Candy", "Candy", "Candy", "Candy", "Candy", "Clam City", "Coral Capers", "Cranky", "Cranky", "Cranky", "Cranky ", "Cranky", "Cranky", "Croctopus Chase", "Elevator Antics", "Elevator Antics - Bonus 1", "Elevator Antics - Bonus 2", "Elevator Antics - Bonus 3", "Forest Frenzy", "Forest Frenzy - Bonus 1", "Forest Frenzy - Bonus 2", "Funky plane", "Funky plane", "Funky plane", "Funky plane", "Funky plane", "Funky plane", "Funky walk", "Funky walk", "Funky walk", "Funky walk", "Funky walk", "Funky walk", "Ice Age Alley", "Ice Age Alley - Bonus 1", "Ice Age Alley - Bonus 2", "Jungle Hijinx", "Jungle Hijinx - Bonus 1", "Jungle Hijinx - Bonus 2", "Loopy Lights", "Loopy Lights - Bonus 1", "Loopy Lights - Bonus 2", "Manic Mincers", "Manic Mincers - Bonus 1", "Manic Mincers - Bonus 2", "Manic Mincers - Ledge Room", "Millstone Mayhem", "Millstone Mayhem - Bonus 1", "Millstone Mayhem - Bonus 2", "Millstone Mayhem - Bonus 3", "Mine Cart Carnage", "Mine Cart Madness", "Mine Cart Madness - Bonus 1", "Mine Cart Madness - Bonus 2", "Mine Cart Madness - Bonus 3", "Misty Mine", "Misty Mine - Bonus 1", "Misty Mine - Bonus 2", "Oil Drum Alley", "Oil Drum Alley - Bonus 1", "Oil Drum Alley - Bonus 2", "Oil Drum Alley - Bonus 3", "Oil Drum Alley - Bonus 4", "Orang-utan Gang", "Orang-utan Gang - Bonus 1", "Orang-utan Gang - Bonus 2", "Orang-utan Gang - Bonus 3", "Orang-utan Gang - Bonus 4", "Orang-utan Gang - Bonus 5", "Platform Perils", "Platform Perils - Bonus 1", "Platform Perils - Bonus 2", "Poison Pond", "Reptile Rumble", "Reptile Rumble - Bonus 1", "Reptile Rumble - Bonus 2", "Reptile Rumble - Bonus 3", "Rope Bridge Rumble", "Rope Bridge Rumble - Bonus 1", "Rope Bridge Rumble - Bonus 2", "Ropey Rampage", "Ropey Rampage - Bonus 1", "Ropey Rampage - Bonus 2", "Slipslide Ride", "Slipslide Ride - Bonus 1", "Slipslide Ride - Bonus 2", "Slipslide Ride - Bonus 3", "Snow Barrel Blast", "Snow Barrel Blast - Bonus 1", "Snow Barrel Blast - Bonus 2", "Snow Barrel Blast - Bonus 3", "Stop & Go Station", "Stop & Go Station - Bonus 1", "Stop & Go Station - Bonus 2", "Tanked Up Trouble", "Tanked Up Trouble - Bonus 1", "Temple Tempest", "Temple Tempest - Bonus 1", "Temple Tempest - Bonus 2", "Torchlight Trouble", "Torchlight Trouble - Bonus 1", "Torchlight Trouble - Bonus 2", "Tree Top Town", "Tree Top Town - Bonus 1", "Tree Top Town - Bonus 2", "Trick Track Trek", "Trick Track Trek - Bonus 1", "Trick Track Trek - Bonus 2", "Trick Track Trek - Bonus 3", "Vulture Culture", "Vulture Culture - Bonus 1", "Vulture Culture - Bonus 2", "Vulture Culture - Bonus 3", "Winky's Walkway", "Winky's Walkway - Bonus 1" };
        String[] cheatSheet = new String[] { "Animal tokens can be found from these entrances:", "", "Enguarde", "Enguarde - Animal Token Room", "Enguarde - Blackout Basement", "Enguarde - Mine Cart Carnage", "Enguarde - Mine Cart Madness (from Bonus 1)", "Enguarde - Mine Cart Madness", "Enguarde - Reptile Rumble", "Enguarde - Reptile Rumble (from Bonus 2)", "Enguarde - Reptile Rumble (from Bonus 3)", "Enguarde - Reptile Rumble (from Bonus 1)", "Enguarde - Slipslide Ride (from Bonus 1)", "Enguarde - Slipslide Ride (from Bonus 2)", "Enguarde - Slipslide Ride (from Bonus 3)", "Enguarde - Slipslide Ride (from warp)", "Enguarde - Slipslide Ride", "Enguarde - Tanked Up Trouble", "", "Expresso", "Expresso - Animal Token Room", "Expresso - Coral Capers", "Expresso - Jungle Hijinx (from Bonus 1)", "Expresso - Jungle Hijinx (from Bonus 2)", "Expresso - Jungle Hijinx (from Kong's Cabin)", "Expresso - Jungle Hijinx", "Expresso - Poison Pond", "Expresso - Stop & Go Station (from Bonus 1)", "Expresso - Stop & Go Station (from Bonus 2)", "Expresso - Stop & Go Station (from warp)", "Expresso - Stop & Go Station", "Expresso - Tree Top Town (from Bonus 1)", "Expresso - Tree Top Town (from Bonus 2)", "Expresso - Tree Top Town (from warp)", "Expresso - Tree Top Town", "Expresso - Winky's Walkway (from Bonus 1)", "Expresso - Winky's Walkway", "", "Rambi", "Rambi - Animal Token Room", "Rambi - Barrel Cannon Canyon", "Rambi - Bouncy Bonanza (from Bonus 1)", "Rambi - Bouncy Bonanza (from Bonus 2)", "Rambi - Bouncy Bonanza (from Winky Room)", "Rambi - Bouncy Bonanza", "Rambi - Misty Mine", "Rambi - Ropey Rampage", "Rambi - Snow Barrel Blast (from Bonus 1)", "Rambi - Snow Barrel Blast (from Bonus 2)", "Rambi - Snow Barrel Blast (from Bonus 3)", "Rambi - Snow Barrel Blast", "Rambi - Temple Tempest (from Bonus 1)", "Rambi - Temple Tempest", "", "Winky", "Winky - Animal Token Room", "Winky - Barrel Cannon Canyon", "Winky - Clam City", "Winky - Croctopus Chase", "Winky - Manic Mincers (from Ledge Room)", "Winky - Trick Track Trek (from Bonus 1)", "Winky - Trick Track Trek (from Bonus 2)", "Winky - Trick Track Trek (from Bonus 3)", "Winky - Trick Track Trek (from warp)", "Winky - Trick Track Trek" };
        // 0xca6c50 - Master array starts

        private void Randomize()
        {
            // Copy our ROM to current every time
            Array.Copy(Global.dataBackup, 0, Global.data, 0, 0x400000);
            staticFlags = "";
            variableFlags = "";
            // Fix (incorrectly) oda bonus in a bonus
            Global.data[0xa6d0e] = 0;

            // Change our cursor
            Cursor.Current = Cursors.WaitCursor;
            // Apply first else bad things happen
            Global.ApplyEdits(ASM.addressesASM_main, ASM.valuesASM_main);
            // Do we have bosses set?
            if (checkBox_bosses.Checked)
                Global.ApplyEdits(ASM.addressesASM_bosses, ASM.valuesASM_bosses);
            // Do we have enemies set?
            if (checkBox_enemies.Checked)
                Global.ApplyEdits(ASM.addressesASM_enemies, ASM.valuesASM_enemies);
            // Do we have animals set?
            if (checkBox_randomizeAnimals.Checked)
                Global.ApplyEdits(ASM.addressesASM_animals, ASM.valuesASM_animals);
            // Do we have carryover set?
/*            if (checkBox_animalCarryover.Checked)
                Global.ApplyEdits(ASM.addressesASM_carryover, ASM.valuesASM_carryover);
                */
            // Set up our seed before randomization happens
            Global.rng = new Random(seed);
            //Global.rng = new Random(5390);
            List<Entrance> entranceList = new List<Entrance>();
            // Loop through every entry on our LUT (in game)
            for (int i = 0xa6c50; i <= 0xa6d50; i++)
            {
                // Is data[i] in master?
                if (Global.masterEntranceLUT_expert.Contains(Global.data[i]))
                {
                    // Add a new entrance
                    entranceList.Add(new Entrance(i, Global.data[i]));
                }

            }
            // Do we apply logic tthis run?
            if (radioButton_valid.Checked)
                AddValidated_expert(entranceList,1);
            else
            {
                Global.entranceLUT_expert.AddRange(Global.entranceLUTBackup_expert);
                foreach (var entrance in entranceList) entrance.Randomize();
                     
            }

            // Add music
            Music music = new Music(checkBox_music.Checked, checkBox_godAwfulMusic.Checked);


            // Apply colors
            int randomNumber = new Random().Next(1, 7);
            Colors colors = new Colors();
            colors.chooseColor[currentMyComboBoxIndex == 9 ? randomNumber : currentMyComboBoxIndex].Apply();
            // Keep rng the way it was
            int x = Global.rng.Next();
            SetGravity();
            
            // Construct seed string
            staticFlags += radioButton_valid.Checked ? "l" : "n";
            variableFlags += colorOrder[currentMyComboBoxIndex == 9 ? randomNumber : currentMyComboBoxIndex];
            variableFlags += checkBox_gravity.Checked ? "G" : "g";
            variableFlags += checkBox_bosses.Checked ? "B" : "b";
            variableFlags += checkBox_music.Checked ? "M" : "m";
            variableFlags += checkBox_godAwfulMusic.Checked ? "F" : "f";
            variableFlags += checkBox_enemies.Checked ? "E" : "e";
            variableFlags += checkBox_randomizeAnimals.Checked ? "A" : "a";
            variableFlags += checkBox_animalCarryover.Checked ? "C" : "c";


            //stringSeed = $"{seed}";
            stringSeed = $"{seed}-{staticFlags}-{variableFlags}";


            // Move animal tokens in token room
            Global.data[0x3dbe7c] = 0x60;
            Global.data[0x3dbe84] = 0x80;
            Global.data[0x3dbe8c] = 0xa0;


            // Apply text to ROM
            Global.ApplyEdits(addressVersion, ASCIIEncoding.ASCII.GetBytes(stringVersion));
            Global.ApplyEdits(addressSeed, ASCIIEncoding.ASCII.GetBytes(stringSeed));
            // Restore cursor
            int index = fileName.LastIndexOf("\\");
            // List out the main bosses to use
            Int32[] bossAddresses = new Int32[] { 0xa6cb8, 0xa6d30, 0xa6d31, 0xa6d33, 0xa6d35 };
            byte[] bossValues = new byte[] { 0x68,0xe0,0xe1,0xe3,0xe5 };
            // Write them to LUT to be constant
            for (int i = 0; i < bossAddresses.Length; i++)
            {
                Global.data[bossAddresses[i]] = bossValues[i];
            }

            if (checkBox_enemies.Checked)
                // Move stupid enemy in 4-1
                //.addr 0x3da93a
                //.data16 0x1830
                Global.Write16(0x3da93a, 0x1830);

            Global.Write16(0x3882b8, 0x0063);

            // Do Cranky hints when ROM is ready
            Cranky cranky = new Cranky();


            // Fix mcc inifinte loop
            //43
            var mccExit = Global.data[0xa6c50 + 0x2e];
            if (mccExit == 0xcc || mccExit == 0x68)
                Global.data[0xa6c50 + 0x2e] = 0x16;

            /*
             
            spoilerLog.Add("Expresso:");
            spoilerLog.Add(entrances[0].TokenDestination(0x6c));
            spoilerLog.Add("");
            spoilerLog.Add("Enguarde:");
            spoilerLog.Add(entrances[0].TokenDestination(0xa6));
            spoilerLog.Add("");
            spoilerLog.Add("Rambi:");
            spoilerLog.Add(entrances[0].TokenDestination(0xd2));
             
             */
            int gnawty = 0xe0,
                necky = 0xe1,
                bee = 0xe5,
                drum = 0xe3,
                kRool = 0x68,
                expresso = Global.data[0xa6c50 + 0x6c],
                enguarde = Global.data[0xa6c50 + 0xa6],
                rambi = Global.data[0xa6c50 + 0xd2],
                winky = Global.data[0xa6c50 + 0xd3];
            int[] bosses = new int[] { 0xe0, 0xe1, 0xe3, 0xe5 };
            if ((bosses.Contains(rambi) || true)/* && bosses.Contains(enguarde)) || true */)
            {
                // Create new directories here
                System.IO.Directory.CreateDirectory(fileName.Substring(0, index) + "\\ROMs");
                System.IO.Directory.CreateDirectory(fileName.Substring(0, index) + "\\Spoiler Logs");
                //The actual saving of the file
                //Only randomize ROM if option selected
                if (checkBox_randomizeROM.Checked)
                    System.IO.File.WriteAllBytes(fileName.Substring(0, index) + "\\ROMs\\DKC Stage Randomizer " + stringVersion + "  " + DateTime.Now.ToString("M_d_yyyy") + " " + stringSeed.Split('-')[0] + ".smc", Global.data); //Include date and random number
                System.IO.File.WriteAllLines(fileName.Substring(0, index) + "\\Spoiler Logs\\DKC Spoiler log for seed  " + stringSeed.Split('-')[0] + ".txt", GenerateSpoilerLog(entranceList, cranky)); //Include date and random number
                if (checkBox_devSpoil.Checked)
                    System.IO.File.WriteAllLines(fileName.Substring(0, index) + "\\Spoiler Logs\\DKC Dev Spoiler log for seed  " + stringSeed.Split('-')[0] + ".txt", GenerateDevSpoilerLog(entranceList)); //Include date and random number
                System.IO.File.WriteAllLines(fileName.Substring(0, index) + "\\DKC note aid.txt", helpFile);
                System.IO.File.WriteAllLines(fileName.Substring(0, index) + "\\DKC cheat sheet (token areas).txt", cheatSheet);
            }
            // Reset cursor to default
            Cursor.Current = Cursors.Default;
            if (warning)
            {
                MessageBox.Show("WARNING! Seed may be impossible! \nBe sure to check the spoiler log ahead of time.\nDon't read the whole spoiler log, just peak if the bosses say \"Not found.\"");
                warning = !warning;
            }

            // Reset static variables
            Global.rng = null;
            Global.entranceLUT_expert = new List<byte>();
            Global.data = new byte[0x400000];
        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //0x1539e080
            OpenFileDialog d = new OpenFileDialog();
            d.Filter = "ROM file (*.smc;*.sfc)|*.smc;*.sfc";
            d.Title = "Select a proper DKC ROM";

            while (d.ShowDialog() == DialogResult.OK)
            {
                //Loading my file and displaying all my content.
                byte[] temp = File.ReadAllBytes(d.FileName);
                // Start reading after the header
                Int32 startingPoint = temp.Length == 0x400000 + 0x200 ? 0x200 : 0;
                Array.Copy(temp, startingPoint, Global.dataBackup, 0, 0x400000);
                // Verify checksum
                if (getCheckSum() == 0x1539ef80)
                {
                    fileName = d.FileName;
                    init(d);

                    break;
                }
                else
                {
                    MessageBox.Show("Invalid file");
                    continue;
                }
            }

        }

        private void init(OpenFileDialog d)
        {
            Task.Run(() =>
            {
                try
                {
                    // Get current version from my pastebin
                    System.Net.WebClient wc = new System.Net.WebClient();
                    byte[] raw = wc.DownloadData("https://pastebin.com/HEHNx6jF");

                    // Parse the string
                    String webData = System.Text.Encoding.UTF8.GetString(raw);
                    // ...<title>Version# - ...
                    String websiteVer = Regex.Split(webData, "<title>")[1].Split(' ')[0];
                    // Version - #
                    String programVer = stringVersion.Split(' ')[2];

                    // Are we running the most current version?
                    if (programVer != websiteVer)
                    {
                        MessageBox.Show($"An update is available");
                        if (MessageBox.Show($"Would you like to update to version {websiteVer} now?", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) == DialogResult.Yes)
                        {
                            System.Diagnostics.Process.Start("https://www.twitch.tv/rainbowsprinklez");
                            Application.Exit();
                        }
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("No internet connection. You may be running outdated software!");
                }

            });
            // Set default combobox
            comboBox_color.SelectedIndex = 0;

            // var rom2 = (byte[])rom1.Clone();
            fileName = d.FileName;
            // Setup hud on successful file load
            panel_hud.Visible = true;
            loadToolStripMenuItem.Enabled = false;
        }

        private void button_randomize_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 1; i++)
            {
                // Setup my seed
                Global.rng = new Random();
            

                seed = Global.rng.Next(0, 10000);
                //seed = 8514;


                Randomize();
            }
            //Show  message so we don't have a silent program
            MessageBox.Show("Randomized!");

        }

        // Set 'low-gravity'
        private void SetGravity ()
        {
            if (checkBox_gravity.Checked)
            {
                // Set these changes if checjed
                Global.data[0x3fb964] = 0xd0;
                Global.data[0x3fb96c] = 0xd4;
                // Animal
                Global.data[0x3fba14] = 0xd4;
                // Tire
                Global.data[0x3fb9ef] = 0xd4;
                // Holding
                Global.data[0x3fba2c] = 0xd4;
                // Rope
                Global.data[0x3fbaa5] = 0xd4;
                // MCM cart
                Global.data[0x3fbb3a] = 0xd4;



            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e) => MessageBox.Show(about);

        private void exitToolStripMenuItem_Click(object sender, EventArgs e) => Application.Exit();

        private void AddValidated_expert(List<Entrance> entranceList, int difficulty)
        {
            int gnawty = 0xe0,
            necky = 0xe1,
            bee = 0xe5,
            drum = 0xe3,
            kRool = 0x68,
            expresso = Global.data[0xa6c50 + 0x6c],
            enguarde = Global.data[0xa6c50 + 0xa6],
            rambi = Global.data[0xa6c50 + 0xd2],
            winky = Global.data[0xa6c50 + 0xd3];
            int[] bosses = new int[] { 0xe0, 0xe1, 0xe3, 0xe5, 0x68 };
            List<string> spoilerLog = new List<string>();
            int x = 0;
            bool containsBoss;

            List<bool[]> accessible;
            do
            {
                // Clear every time
                spoilerLog = new List<string>();
                accessible = new List<bool[]>();
                // Load LUT 1st time, refill after
                Global.entranceLUT_expert.AddRange(Global.entranceLUTBackup_expert);
                foreach (var entrance in entranceList)
                    // Randomize every stage
                    entrance.Randomize();

                foreach (var entrance in entranceList)
                {
                    var sanity = entrance.SanityCheck_expert();
                    accessible.Add(sanity);
                    if (!sanity[0x68] || !sanity[0xe0] || !sanity[0xe1] || !sanity[0xe3] || !sanity[0xe5] || !sanity[0x34])
                        break;
                }

                // Empty because we made my LUT static
                Global.entranceLUT_expert = new List<byte>();

                expresso = Global.data[0xa6c50 + 0x6c];
                enguarde = Global.data[0xa6c50 + 0xa6];
                rambi = Global.data[0xa6c50 + 0xd2];
                winky = Global.data[0xa6c50 + 0xd3];


                // This ensures things could be found
                //spoilerLog.Add("K Rool:");
                spoilerLog.Add(entranceList[0].GenerateSpoilerString(0x68));
                //spoilerLog.Add("Gnawty:");
                spoilerLog.Add(entranceList[0].GenerateSpoilerString(0xe0));
                //spoilerLog.Add("Necky:");
                spoilerLog.Add(entranceList[0].GenerateSpoilerString(0xe1));
                //spoilerLog.Add("Bumble B Rumble:");
                spoilerLog.Add(entranceList[0].GenerateSpoilerString(0xe5));
                //spoilerLog.Add("Dumb Drum:");
                spoilerLog.Add(entranceList[0].GenerateSpoilerString(0xe3));

                containsBoss = (bosses.Contains(expresso) || bosses.Contains(enguarde) || bosses.Contains(rambi) || bosses.Contains(winky));

                // Can every reach kkr and bosses?
            } while (!(accessible.All(e => e[0x68] && e[0xe0] && e[0xe1] && e[0xe3] && e[0xe5])  && containsBoss) || (spoilerLog.Contains("Not found.")));
        }
        private List<String> GenerateSpoilerLog(List<Entrance> entrances, Cranky cranky)
        {
            List<String> spoilerLog = new List<string>();
            spoilerLog.Add("// Seed: " + stringSeed.Split('-')[0]);
            spoilerLog.Add("===========================================");
            spoilerLog.Add("================SPOILER LOG================");
            spoilerLog.Add("===========================================");
            spoilerLog.Add("*******************************************");
            spoilerLog.Add("*******************CANDY*******************");
            spoilerLog.Add("*******************************************");
            spoilerLog.Add("Candy w1:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xfa));
            spoilerLog.Add("Candy w2:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xfb));
            spoilerLog.Add("Candy w3:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xff));
            spoilerLog.Add("Candy w4:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xfc));
            spoilerLog.Add("Candy w5:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xfd));
            spoilerLog.Add("Candy w6:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xfe));
            spoilerLog.Add("*******************************************");
            spoilerLog.Add("*******************CRANKY******************");
            spoilerLog.Add("*******************************************");
            spoilerLog.Add("Cranky w1:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xee));
            spoilerLog.Add("Cranky w2:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xef));
            spoilerLog.Add("Cranky w3:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xf3));
            spoilerLog.Add("Cranky w4:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xf0));
            spoilerLog.Add("Cranky w5:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xf1));
            spoilerLog.Add("Cranky w6:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xf2));
            spoilerLog.Add("*******************************************");
            spoilerLog.Add("*******************FUNKY*******************");
            spoilerLog.Add("*******************************************");
            spoilerLog.Add("Funky w1:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xf4));
            spoilerLog.Add("Funky w2:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xf5));
            spoilerLog.Add("Funky w3:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xf9));
            spoilerLog.Add("Funky w4:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xf6));
            spoilerLog.Add("Funky w5:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xf7));
            spoilerLog.Add("Funky w6:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xf8));

            spoilerLog.Add("*******************************************");
            spoilerLog.Add("****************COMMON HUBS****************");
            spoilerLog.Add("*******************************************");
            // Behind the scenes work
            // Check which path is shortest to mincers.
            String[] mincerPaths = new String[] { entrances[0].GenerateSpoilerString(0x12), entrances[0].GenerateSpoilerString(0x7a), entrances[0].GenerateSpoilerString(0x7b), entrances[0].GenerateSpoilerString(0x7c) };
            // Sort our list based on length
            Array.Sort(mincerPaths, (x1, x2) => x1.Length.CompareTo(x2.Length));
            // Filter our results to only show available
            mincerPaths = Array.FindAll(mincerPaths, x => x.Contains(","));

            // Check which path is shortest to mincers.
            String[] ogangPaths = new String[] { entrances[0].GenerateSpoilerString(0xd), entrances[0].GenerateSpoilerString(0x71), entrances[0].GenerateSpoilerString(0x72), entrances[0].GenerateSpoilerString(0x73), entrances[0].GenerateSpoilerString(0x74), entrances[0].GenerateSpoilerString(0x75) };
            // Sort our list based on length
            Array.Sort(ogangPaths, (x1, x2) => x1.Length.CompareTo(x2.Length));
            // Filter our results to only show available
            ogangPaths = Array.FindAll(ogangPaths, x => x.Contains(","));

            spoilerLog.Add("Animal room:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0x34));
            spoilerLog.Add("");
            spoilerLog.Add("Ogang:");
            spoilerLog.Add(ogangPaths[0]);
            spoilerLog.Add("");
            spoilerLog.Add("Mincers:");
            spoilerLog.Add(mincerPaths[0]);
            spoilerLog.Add("");

            spoilerLog.Add("*******************************************");
            spoilerLog.Add("**************ANIMAL TOKENS****************");
            spoilerLog.Add("*******************************************");
            
            spoilerLog.Add("Expresso:");
            spoilerLog.Add(entrances[0].TokenDestination(0x6c));
            spoilerLog.Add("");
            spoilerLog.Add("Enguarde:");
            spoilerLog.Add(entrances[0].TokenDestination(0xa6));
            spoilerLog.Add("");
            spoilerLog.Add("Rambi:");
            spoilerLog.Add(entrances[0].TokenDestination(0xd2));
            spoilerLog.Add("");
            spoilerLog.Add("Winky:");
            spoilerLog.Add(entrances[0].TokenDestination(0xd3));
            spoilerLog.Add("");


            spoilerLog.Add("*******************************************");
            spoilerLog.Add("*******************HINTS*******************");
            spoilerLog.Add("*******************************************");
            foreach (var hint in cranky.GetHintList())
            {
                spoilerLog.Add(hint);
            }


            spoilerLog.Add("*******************************************");
            spoilerLog.Add("*******************BOSSES******************");
            spoilerLog.Add("*******************************************");

            spoilerLog.Add("K Rool:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0x68));
            spoilerLog.Add("");
            spoilerLog.Add("Gnawty:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xe0));
            spoilerLog.Add("");
            spoilerLog.Add("Necky:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xe1));
            spoilerLog.Add("");
            spoilerLog.Add("Bumble B Rumble:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xe5));
            spoilerLog.Add("");
            spoilerLog.Add("Dumb Drum:");
            spoilerLog.Add(entrances[0].GenerateSpoilerString(0xe3));
            spoilerLog.Add("");


            return spoilerLog;
        }

        private List<String> GenerateDevSpoilerLog(List<Entrance> entrances)
        {
            List<String> spoilerLog = new List<string>();
            spoilerLog.Add("// Seed: " + stringSeed.Split('-')[0]);
            spoilerLog.Add("===========================================");
            spoilerLog.Add("=============DEV SPOILER LOG===============");
            spoilerLog.Add("===========================================");
            foreach (var entrance in Global.sortedMasterEntranceLUT_expert)
            {
                spoilerLog.Add($"{entrances[0].named3eCodes[entrance]}:");
                spoilerLog.Add(entrances[0].GenerateSpoilerString(entrance));
                spoilerLog.Add("");
            }

            spoilerLog.Add("*******************************************");
            spoilerLog.Add("**************ANIMAL TOKENS****************");
            spoilerLog.Add("*******************************************");

            spoilerLog.Add("Expresso:");
            spoilerLog.Add(entrances[0].TokenDestination(0x6c));
            spoilerLog.Add("");
            spoilerLog.Add("Enguarde:");
            spoilerLog.Add(entrances[0].TokenDestination(0xa6));
            spoilerLog.Add("");
            spoilerLog.Add("Rambi:");
            spoilerLog.Add(entrances[0].TokenDestination(0xd2));
            spoilerLog.Add("");
            spoilerLog.Add("Winky:");
            spoilerLog.Add(entrances[0].TokenDestination(0xd3));
            spoilerLog.Add("");

            return spoilerLog;
        }


        private void button_seedEnter_Click(object sender, EventArgs e)
        {
            // Match using our pattern
            MatchCollection matches = Regex.Matches(textBox_seedEnter.Text, fileRegex);

            if (matches.Count != 0)
            {
                // Start at seed # (1) then cycle through flags
                int potentialSeedNumber = Convert.ToInt32(matches[0].Groups[0].Value);
                if (potentialSeedNumber == 69 || potentialSeedNumber == 420)
                    MessageBox.Show("No mames");
                if (potentialSeedNumber <= 10000 && potentialSeedNumber != 0)
                {
                    // seed
                    seed = potentialSeedNumber;

                    Randomize();
                    //Show  message so we don't have a silent program
                    MessageBox.Show("Customized!");
                }
                else
                {
                    MessageBox.Show("Invalid. Try again. Don't give up!");
                }
            }
            else
                MessageBox.Show("Invalid. Try again. Don't give up!");
        }
        // Force music to stay checked if godawful is checked
        private void checkBox_music_CheckedChanged(object sender, EventArgs e) => checkBox_music.Checked = checkBox_godAwfulMusic.Checked == true ? true : checkBox_music.Checked;

        private void checkBox_godAwfulMusic_CheckedChanged(object sender, EventArgs e)
        {
            // If we set to checked
            if (checkBox_godAwfulMusic.Checked == true)
                // Set music
                checkBox_music.Checked = true;
        }
        private Int32 getCheckSum()
        {
            Int32 total = 0;
            foreach (var b in Global.dataBackup) total += b;
            return total;
        }

        private void comboBox_color_SelectedIndexChanged(object sender, EventArgs e)
        {
            currentMyComboBoxIndex = comboBox_color.SelectedIndex;
        }

        private void button_fullyRandomize_Click(object sender, EventArgs e)
        {
            // Setup my seed
            Global.rng = new Random();
            seed = Global.rng.Next(0, 10000);
            CheckBox[] chkbx = new CheckBox[]
            {
                checkBox_gravity,
                checkBox_music,
                checkBox_godAwfulMusic,
                checkBox_bosses,
                checkBox_enemies,
                checkBox_randomizeAnimals
            };
            foreach (var item in chkbx)
            {
                item.Checked = false;
            }

            /*  Alter all flags jere
            Use bits 0-6
            0 - logic
            1 - gravity
            2 - music
            3 - god awful music
            4 - bosses
            5 - enemies
            6 - animal buddies
            Random color
           */
            var randomFlags = new Random().Next(0, 100000);
           if ((randomFlags & 2) == 2)
           {
                radioButton_valid.Checked = true;
                radioButton_notValid.Checked = false;
           }
           else
           {
                radioButton_valid.Checked = false;
                radioButton_notValid.Checked = true;
           }
            checkBox_gravity.Checked = (randomFlags & 4) == 4;
            checkBox_music.Checked = (randomFlags & 8) == 8;
            checkBox_godAwfulMusic.Checked = (randomFlags & 16) == 16;
            checkBox_bosses.Checked = (randomFlags & 32) == 32;
            checkBox_enemies.Checked = (randomFlags & 64) == 64;
            checkBox_randomizeAnimals.Checked = (randomFlags & 128) == 128;
            currentMyComboBoxIndex = 9;


            Randomize();

            foreach (var item in chkbx)
            {
                item.Checked = false;
            }


            // Unchecks eveey checkbox
            //UncheckAll(this);

            // Recheck after
            checkBox_randomizeROM.Checked = true;

            radioButton_notValid.Checked = false;
            radioButton_valid.Checked = true;

            //Show  message so we don't have a silent program
            MessageBox.Show("Fully randomized!");
        }
        // https://social.msdn.microsoft.com/Forums/vstudio/en-US/61a33ecd-98f2-4ad7-8077-7e8aaeb0b0b3/uncheck-all-checkboxes?forum=csharpgeneral
        private void UncheckAll(Control ctrl)
        {
            CheckBox chkBox = ctrl as CheckBox;
            if (chkBox == null)
            {
                foreach (Control child in ctrl.Controls)
                {
                    UncheckAll(child);
                }
            }
            else
            {
                chkBox.Checked = false;
            }
        }
    }
}
