﻿using DKC_Entrance_Randomizer;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DKC_Stage_Randomizer
{
    public partial class Entrance
    {
        // We need to pass multiple objects at a time to queue
        public struct ShortPath
        {
            public List<bool> visited;
            public int stepNumber;
            public byte currentEntrance;

            public ShortPath(int stepNumber, byte currentEntrance, List<bool> visited)
            {
                this.visited = visited;
                this.stepNumber = stepNumber;
                this.currentEntrance = currentEntrance;
            }
        }


        public String[] named3eCodes = new String[]
        {
            "Jungle Hijinx (Reptile Rumble object map?)", "Reptile Rumble (level exit)", "Reptile Rumble - Bonus 1", "Bouncy Bonanza - Winky Room", "Reptile Rumble - Bonus 3", "Manic Mincers - Bonus 1", "Jungle Hijinx - Bonus 1", "Bouncy Bonanza (level exit)", "Jungle Hijinx (from Bonus 1)", "Reptile Rumble (from Bonus 1)", "Misty Mine (level exit)", "Reptile Rumble (from Bonus 3)", "Ropey Rampage (level exit)", "Orang-utan Gang (level exit)", "Jungle Hijinx (start)", "Ropey Rampage (from Save)", "Bouncy Bonanza (from Winky Room)", "Bouncy Bonanza - Bonus 2", "Manic Mincers (level exit)", "Torchlight Trouble (from Save)", "Torchlight Trouble (level exit)", "Bouncy Bonanza (from Save)", "Jungle Hijinx (level exit)", "Barrel Cannon Canyon (level exit)", "Elevator Antics (level exit)", "Barrel Cannon Canyon (from Save)", "Jungle Hijinx - Bonus 2", "Ropey Rampage - Bonus 2", "Ropey Rampage - Bonus 1", "Orang-utan Gang (from Save)", "Orang-utan Gang - Bonus 3", "Orang-utan Gang - Bonus 2", "Orang-utan Gang - Bonus 1", " empty jungle room + boss music???", "Poison Pond (level exit)", "Elevator Antics (from Save)", "Snow Barrel Blast (level exit)", "Jungle Hijinx (from Save)", "Reptile Rumble (from Save)", "Mine Cart Madness (level exit)", "Snow Barrel Blast (from Save)", "Manic Mincers (from Save)", "Poison Pond (from Save)", "Platform Perils (level exit)", "Platform Perils (from Save)", "Misty Mine (from Save)", "Mine Cart Carnage (level exit)", "Trick Track Trek (level exit)", "Tanked Up Trouble (level exit)", "Stop & Go Station (level exit)", "Misty Mine - Bonus 2", "Misty Mine - Bonus 1", "Animal Token Room", "Millstone Mayhem (from warp)", "Loopy Lights (level exit)", "Loopy Lights - Bonus 2", "Mine Cart Carnage (from Save)", "Trick Track Trek (from Save)", "Tanked Up Trouble (from Save)", "Mine Cart Madness (from Save)", "Stop & Go Station (from Save)", "Loopy Lights (from Save)", "Croctopus Chase (level exit)", "Croctopus Chase (from Save)", "Oil Drum Alley (level exit)", "Blackout Basement (level exit)", "Millstone Mayhem (level exit)", "Temple Tempest (level exit)", "Oil Drum Alley (from Save)", "Blackout Basement (from Save)", "Barrel Cannon Canyon - Bonus 1", "Jungle Hijinx - Kong's Banana Hoard (empty)", "Reptile Rumble - Bonus 2", "Loopy Lights - Bonus 1", "Stop & Go Station - Bonus 2", "Stop & Go Station - Bonus 1", "Jungle Hijinx - Kong's Banana Hoard (full)", "Mine Cart Madness - Bonus 1", "Platform Perils - Bonus 1", "Winky's Walkway - Bonus 1", "Platform Perils - Bonus 2", "Winky's Walkway (from Bonus 1)", "Temple Tempest - Bonus 1", "Temple Tempest - Bonus 2", "Tree Top Town (warp)", "Millstone Mayhem - Bonus 1", "Millstone Mayhem - Bonus 2", "Millstone Mayhem - Bonus 3", "Millstone Mayhem (from Save)", "Temple Tempest (from Save)", "Orang-utan Gang - Bonus 5", "Orang-utan Gang - Bonus 4", "Jungle Hijinx - Kong's Cabin", "Barrel Cannon Canyon - Bonus 2", " Credits", "Jungle Hijinx (from Kong's Banana Hoard)", "Oil Drum Alley - Bonus 4", "Oil Drum Alley - Bonus 2", "Slipslide Ride (warp)", "Oil Drum Alley - Bonus 1", "Blackout Basement - Bonus 1", "Vulture Culture (warp)", "Snow Barrel Blast - Bonus 3", "Snow Barrel Blast - Bonus 1", "Gangplank Galleon", "Snow Barrel Blast - Bonus 2", "Ice Age Alley - Bonus 1", "Ice Age Alley - Bonus 2", "Expresso Bonus", "Slipslide Ride (level exit)", "Jungle Hijinx (from Bonus 2)", "Ropey Rampage (from Bonus 1)", "Ropey Rampage (from Bonus 2)", "Orang-utan Gang (from Bonus 4)", "Orang-utan Gang (from Bonus 2)", "Orang-utan Gang (from Bonus 1)", "Orang-utan Gang (from Bonus 3)", "Orang-utan Gang (from Bonus 5)", "Barrel Cannon Canyon (from Bonus 1)", "Barrel Cannon Canyon (from Bonus 2)", "Bouncy Bonanza (from Bonus 1)", "Bouncy Bonanza (from Bonus 2)", "Manic Mincers (from Bonus 1)", "Manic Mincers (from Ledge Room)", "Manic Mincers (from Bonus 2)", "Elevator Antics (from Bonus 1)", "Elevator Antics (from Bonus 2)", "Elevator Antics (from Bonus 3)", "Misty Mine (from Bonus 1)", "Misty Mine (from Bonus 2)", "Stop & Go Station (from Bonus 1)", "Stop & Go Station (from Bonus 2)", "Loopy Lights (from Bonus 1)", "Loopy Lights (from Bonus 2)", "Platform Perils (from Bonus 1)", "Platform Perils (from Bonus 2)", "Trick Track Trek (from Bonus 1)", "Trick Track Trek (from Bonus 3)", "Trick Track Trek (from Bonus 2)", "Tanked Up Trouble (from Bonus 1)", "Mine Cart Madness (from Bonus 1)", "Mine Cart Madness (from Bonus 2)", "Mine Cart Madness (from Bonus 3)", "Oil Drum Alley (from Bonus 1)", "Oil Drum Alley (from Bonus 2/3)", "Oil Drum Alley (from Bonus 4)", "Blackout Basement (from Bonus 1)", "Blackout Basement (from Bonus 2)", "Snow Barrel Blast (from Bonus 1)", "Snow Barrel Blast (from Bonus 2)", "Snow Barrel Blast (from Bonus 3)", "Bouncy Bonanza - Bonus 1", "Manic Mincers - Bonus 2", "Manic Mincers - Ledge Room", "Elevator Antics - Bonus 1", "Elevator Antics - Bonus 2", "Elevator Antics - Bonus 3", "Trick Track Trek - Bonus 3", "Trick Track Trek - Bonus 2", "Tanked Up Trouble - Bonus 1", "Mine Cart Madness - Bonus 2", "Trick Track Trek - Bonus 1", "Mine Cart Madness - Bonus 3", "Blackout Basement - Bonus 2", "Tree Top Town (level exit)", "Vulture Culture (level exit)", "Enguarde Bonus", "Ice Age Alley (level exit)", "Ice Age Alley (from Save)", "Tree Top Town (from Save)", "Vulture Culture (from Save)", "Slipslide Ride (from Save)", "Ice Age Alley (from Bonus 1)", "Ice Age Alley (from Bonus 2)", "Millstone Mayhem (from Bonus 1)", "Millstone Mayhem (from Bonus 2)", "Millstone Mayhem (from Bonus 3)", "Temple Tempest (from Bonus 1)", "Temple Tempest (from Bonus 2)", "Tree Top Town - Bonus 2", "Tree Top Town - Bonus 1", "Tree Top Town (from Bonus 1)", "Tree Top Town (from Bonus 2)", "Vulture Culture - Bonus 1", "Vulture Culture - Bonus 2", "Vulture Culture - Bonus 3", "Vulture Culture (from Bonus 1)", "Vulture Culture (from Bonus 2)", "Vulture Culture (from Bonus 3)", "Trick Track Trek (warp)", "Oil Drum Alley - Bonus 3", "Coral Capers (level exit)", "Coral Capers (from Save)", "Torchlight Trouble - Bonus 1", "Torchlight Trouble (from Bonus 1)", "Torchlight Trouble - Bonus 2", "Torchlight Trouble (from Bonus 2)", "Slipslide Ride - Bonus 2", "Slipslide Ride - Bonus 3", "Slipslide Ride (from Bonus 1)", "Slipslide Ride (from Bonus 2)", "Reptile Rumble (from Bonus 2)", "Slipslide Ride - Bonus 1", "Slipslide Ride (from Bonus 3)", "Mine Cart Carnage (warp)", "Stop & Go Station (warp)", "Rope Bridge Rumble (level exit)", "Rope Bridge Rumble (from Save)", "Forest Frenzy (level exit)", "Forest Frenzy (from Save)", "Rambi Bonus", "Winky Bonus", "Forest Frenzy - Bonus 2", "Rope Bridge Rumble - Bonus 1", "Rope Bridge Rumble (from Bonus 2)", "Rope Bridge Rumble - Bonus 2", "Rope Bridge Rumble (from Bonus 1)", "Winky's Walkway (level exit)", "Winky's Walkway (from Save)", "Forest Frenzy (from Bonus 2)", "Forest Frenzy - Bonus 1", "Forest Frenzy (from Bonus 1)", "Clam City (level exit)", "Clam City (from Save)", "Very Gnawty's Lair", "Necky's Nuts", "Really Gnawty Rampage", "Boss Dumb Drum", "Necky's Revenge", "Bumble B Rumble", "Funky (plane exit)", "Funky (plane exit)", "Funky (plane exit)", "Funky (plane exit)", "crash", "crash", "Funky (plane exit)", "Funky (plane exit)", "Cranky", "Cranky", "Cranky", "Cranky", "Cranky", "Cranky", "Funky (walk exit)", "Funky (walk exit)", "Funky (walk exit)", "Funky (walk exit)", "Funky (walk exit)", "Funky (walk exit)", "Candy", "Candy", "Candy", "Candy", "Candy", "Candy"
        };

        private byte valueInLUT;
        private Int32 addressInLUT;
        private List<byte> indexesUsed = new List<byte> ();

        // 0xca6c50 - stage array starts
        public Entrance (Int32 addressInLUT,byte valueInLUT)
        {
            this.addressInLUT = addressInLUT;
            this.valueInLUT = valueInLUT;
            this.AddSanity();
        }

        public void Randomize()
        {
            Global.data[this.addressInLUT] = GetNextByte_expert();
        }

        private byte GetNextByte_expert()
        {
            // Get next random number
            var number = Global.rng.Next(0, Global.entranceLUT_expert.Count);
            // Get ID based on number
            byte nextID = Global.entranceLUT_expert[number];

            // It's dead to us now
            Global.entranceLUT_expert.RemoveAt(number);
            this.valueInLUT = nextID;
            return nextID;

        }

        // Check sanity
        public bool[] SanityCheck()
        {
            // Read the code at this address
            // This loads an entrance into 'start'
            byte start = Global.data[this.addressInLUT];
            bool[] checklist = new bool[256];
            Queue<byte> queue = new Queue<byte>();

            // Just in case animal room shows up
            if ((start >= 0xe0 && start <= 0xed) || (start >= 0xfa && start <= 0xff))
                // 0x68 is kkr. return true if animal tokens found
                return Enumerable.Repeat<bool>(true, 0x69).ToArray();

            queue.Enqueue(start);
            // Find which ones are accessible
            while (queue.Count > 0)
            {
                // Pull (from bottom) next stage into current
                byte currentStage = queue.Dequeue();

                if ((start >= 0xe0 && start <= 0xe5))
                    // 0x68 is kkr. return true if boss found
                    continue;

                // Have we been here?
                if (!checklist[currentStage])
                {
                    // Mark stage as 'been here'
                    checklist[currentStage] = true;

                    // Loop through available exits from this entrance
                    foreach (var exit in sanity[currentStage])
                    {
                        // Load entrance at exit's index
                        // of custom array 0xa6c50
                        byte entrance = Global.data[0xa6c50 + exit];
                        // Stack on queue
                        queue.Enqueue(entrance);
                    }

                }
            }

            return checklist;
        }
        // Check sanity
        public bool[] SanityCheck_expert()
        {
            // Read the code at this address
            // This loads an entrance into 'start'
            byte start = this.valueInLUT;
            bool[] checklist = new bool[256];
            Queue<byte> queue = new Queue<byte>();


            queue.Enqueue(start);
            // Find which ones are accessible
            while (queue.Count > 0)
            {
                // Pull (from bottom) next stage into current
                byte currentStage = queue.Dequeue();

                if ((start >= 0xe0 && start <= 0xe5))
                    // 0x68 is kkr. return true if boss found
                    continue;

                // Skip animal token room and bosses and family
                if (currentStage >= 0xe0)
                {
                    checklist[currentStage] = true;
                    continue;
                }
                // Have we been here?
                if (!checklist[currentStage])
                {
                    // Mark stage as 'been here'
                    checklist[currentStage] = true;

                    // Loop through available exits from this entrance
                    foreach (var exit in sanity[currentStage])
                    {
                        // Load entrance at exit's index
                        // of custom array 0xa6c50
                        byte entrance = Global.data[0xa6c50 + exit];
                        // Stack on queue
                        queue.Enqueue(entrance);
                    }

                }
            }

            return checklist;
        }
        // Return a string of our path
        public String GenerateSpoilerString(byte end)
        {
            Queue<SpoilerLog> queue = new Queue<SpoilerLog>();
            // Have we been here before?
            bool[] checklist = new bool[256];

            queue.Enqueue(new SpoilerLog(new List<String>() { named3eCodes[0xe] }, 0xe));
            // Find which ones are accessible
            while (queue.Count > 0)
            {
                // Pull (from bottom) next spoiler log into current
                SpoilerLog log = queue.Dequeue();

                List<String> pathString = log.pathTakenString;
                byte currentStage = log.current;
                if (currentStage == end)
                {
                    pathString.Add(named3eCodes[currentStage].Split('(')[0]);
                    return String.Join(", ", pathString);
                }

                if ((currentStage >= 0xe0 && currentStage <= 0xe5))
                    continue;

                // Have we been here?
                if (!checklist[currentStage])
                {
                    // Mark stage as 'been here'
                    checklist[currentStage] = true;

                    // Loop through available exits from this entrance
                    foreach (var exit in sanity[currentStage])
                    {
                        // Load entrance at exit's index
                        // of custom array 0xa6c50
                        byte entrance = Global.data[0xa6c50 + exit];
                        if (entrance == 0)
                            MessageBox.Show("hi");

                        // Add exit to path taken
                        pathString.Add(named3eCodes[exit]);
                        // Stack on queue
                        queue.Enqueue(new SpoilerLog(pathString, entrance));
                        // Remove potential destination after we create a new SpoilerLog
                        pathString.Remove(named3eCodes[exit]);

                    }

                }
            }

            return "Not found.";
        }
        public String TokenDestination(byte tokenCode)
        {
            return named3eCodes[Global.data[0xa6c50 + tokenCode]].Split('(')[0];
        }
    }
}
