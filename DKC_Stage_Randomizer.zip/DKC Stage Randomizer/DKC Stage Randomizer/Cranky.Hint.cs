﻿using DKC_Stage_Randomizer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKC_Entrance_Randomizer
{
    public partial class Cranky
    {
        private String[] named3eCodes = new String[] { "Jungle Hijinx (Reptile Rumble object map?)", "Reptile Rumble (level exit)", "Reptile Rumble - Bonus 1", "Bouncy Bonanza - Winky Room", "Reptile Rumble - Bonus 3", "Manic Mincers - Bonus 1", "Jungle Hijinx - Bonus 1", "Bouncy Bonanza (level exit)", "Jungle Hijinx (from Bonus 1)", "Reptile Rumble (from Bonus 1)", "Misty Mine (level exit)", "Reptile Rumble (from Bonus 3)", "Ropey Rampage (level exit)", "Orang-utan Gang (level exit)", "Jungle Hijinx (start)", "Ropey Rampage (from Save)", "Bouncy Bonanza (from Winky Room)", "Bouncy Bonanza - Bonus 2", "Manic Mincers (level exit)", "Torchlight Trouble (from Save)", "Torchlight Trouble (level exit)", "Bouncy Bonanza (from Save)", "Jungle Hijinx (level exit)", "Barrel Cannon Canyon (level exit)", "Elevator Antics (level exit)", "Barrel Cannon Canyon (from Save)", "Jungle Hijinx - Bonus 2", "Ropey Rampage - Bonus 2", "Ropey Rampage - Bonus 1", "Orang-utan Gang (from Save)", "Orang-utan Gang - Bonus 1", "Orang-utan Gang - Bonus 2", "Orang-utan Gang - Bonus 4", " empty jungle room + boss music???", "Poison Pond (level exit)", "Elevator Antics (from Save)", "Snow Barrel Blast (level exit)", "Jungle Hijinx (from Save)", "Reptile Rumble (from Save)", "Mine Cart Madness (level exit)", "Snow Barrel Blast (from Save)", "Manic Mincers (from Save)", "Poison Pond (from Save)", "Platform Perils (level exit)", "Platform Perils (from Save)", "Misty Mine (from Save)", "Mine Cart Carnage (level exit)", "Trick Track Trek (level exit)", "Tanked Up Trouble (level exit)", "Stop & Go Station (level exit)", "Misty Mine - Bonus 2", "Misty Mine - Bonus 1", "Animal Token Room", "Millstone Mayhem (from warp)", "Loopy Lights (level exit)", "Loopy Lights - Bonus 2", "Mine Cart Carnage (from Save)", "Trick Track Trek (from Save)", "Tanked Up Trouble (from Save)", "Mine Cart Madness (from Save)", "Stop & Go Station (from Save)", "Loopy Lights (from Save)", "Croctopus Chase (level exit)", "Croctopus Chase (from Save)", "Oil Drum Alley (level exit)", "Blackout Basement (level exit)", "Millstone Mayhem (level exit)", "Temple Tempest (level exit)", "Oil Drum Alley (from Save)", "Blackout Basement (from Save)", "Barrel Cannon Canyon - Bonus 1", "Jungle Hijinx - Kong's Banana Hoard (empty)", "Reptile Rumble - Bonus 2", "Loopy Lights - Bonus 1", "Stop & Go Station - Bonus 2", "Stop & Go Station - Bonus 1", "Jungle Hijinx - Kong's Banana Hoard (full)", "Mine Cart Madness - Bonus 1", "Platform Perils - Bonus 1", "Winky's Walkway - Bonus 1", "Platform Perils - Bonus 2", "Winky's Walkway (from Bonus 1)", "Temple Tempest - Bonus 1", "Temple Tempest - Bonus 2", "Tree Top Town (warp)", "Millstone Mayhem - Bonus 1", "Millstone Mayhem - Bonus 2", "Millstone Mayhem - Bonus 3", "Millstone Mayhem (from Save)", "Temple Tempest (from Save)", "Orang-utan Gang - Bonus 5", "Orang-utan Gang - Bonus 3", "Jungle Hijinx - Kong's Cabin", "Barrel Cannon Canyon - Bonus 2", " Credits", "Jungle Hijinx (from Kong's Banana Hoard)", "Oil Drum Alley - Bonus 4", "Oil Drum Alley - Bonus 2", "Slipslide Ride (warp)", "Oil Drum Alley - Bonus 1", "Blackout Basement - Bonus 1", "Vulture Culture (warp)", "Snow Barrel Blast - Bonus 3", "Snow Barrel Blast - Bonus 1", "Gangplank Galleon", "Snow Barrel Blast - Bonus 2", "Ice Age Alley - Bonus 1", "Ice Age Alley - Bonus 2", "Expresso Bonus (level exit)", "Slipslide Ride (level exit)", "Jungle Hijinx (from Bonus 2)", "Ropey Rampage (from Bonus 1)", "Ropey Rampage (from Bonus 2)", "Orang-utan Gang (from Bonus 4)", "Orang-utan Gang (from Bonus 2)", "Orang-utan Gang (from Bonus 1)", "Orang-utan Gang (from Bonus 3)", "Orang-utan Gang (from Bonus 5)", "Barrel Cannon Canyon (from Bonus 1)", "Barrel Cannon Canyon (from Bonus 2)", "Bouncy Bonanza (from Bonus 1)", "Bouncy Bonanza (from Bonus 2)", "Manic Mincers (from Bonus 1)", "Manic Mincers (from Ledge Room)", "Manic Mincers (from Bonus 2)", "Elevator Antics (from Bonus 1)", "Elevator Antics (from Bonus 2)", "Elevator Antics (from Bonus 3)", "Misty Mine (from Bonus 1)", "Misty Mine (from Bonus 2)", "Stop & Go Station (from Bonus 1)", "Stop & Go Station (from Bonus 2)", "Loopy Lights (from Bonus 1)", "Loopy Lights (from Bonus 2)", "Platform Perils (from Bonus 1)", "Platform Perils (from Bonus 2)", "Trick Track Trek (from Bonus 1)", "Trick Track Trek (from Bonus 3)", "Trick Track Trek (from Bonus 2)", "Tanked Up Trouble (from Bonus 1)", "Mine Cart Madness (from Bonus 1)", "Mine Cart Madness (from Bonus 2)", "Mine Cart Madness (from Bonus 3)", "Oil Drum Alley (from Bonus 1)", "Oil Drum Alley (from Bonus 2/3)", "Oil Drum Alley (from Bonus 4)", "Blackout Basement (from Bonus 1)", "Blackout Basement (from Bonus 2)", "Snow Barrel Blast (from Bonus 1)", "Snow Barrel Blast (from Bonus 2)", "Snow Barrel Blast (from Bonus 3)", "Bouncy Bonanza - Bonus 1", "Manic Mincers - Bonus 2", "Manic Mincers - Ledge Room", "Elevator Antics - Bonus 1", "Elevator Antics - Bonus 2", "Elevator Antics - Bonus 3", "Trick Track Trek - Bonus 3", "Trick Track Trek - Bonus 2", "Tanked Up Trouble - Bonus 1", "Mine Cart Madness - Bonus 2", "Trick Track Trek - Bonus 1", "Mine Cart Madness - Bonus 3", "Blackout Basement - Bonus 2", "Tree Top Town (level exit)", "Vulture Culture (level exit)", "Enguarde Bonus", "Ice Age Alley (level exit)", "Ice Age Alley (from Save)", "Tree Top Town (from Save)", "Vulture Culture (from Save)", "Slipslide Ride (from Save)", "Ice Age Alley (from Bonus 1)", "Ice Age Alley (from Bonus 2)", "Millstone Mayhem (from Bonus 1)", "Millstone Mayhem (from Bonus 2)", "Millstone Mayhem (from Bonus 3)", "Temple Tempest (from Bonus 1)", "Temple Tempest (from Bonus 2)", "Tree Top Town - Bonus 2", "Tree Top Town - Bonus 1", "Tree Top Town (from Bonus 1)", "Tree Top Town (from Bonus 2)", "Vulture Culture - Bonus 1", "Vulture Culture - Bonus 2", "Vulture Culture - Bonus 3", "Vulture Culture (from Bonus 1)", "Vulture Culture (from Bonus 2)", "Vulture Culture (from Bonus 3)", "Trick Track Trek (warp)", "Oil Drum Alley - Bonus 3", "Coral Capers (level exit)", "Coral Capers (from Save)", "Torchlight Trouble - Bonus 1", "Torchlight Trouble (from Bonus 1)", "Torchlight Trouble - Bonus 2", "Torchlight Trouble (from Bonus 2)", "Slipslide Ride - Bonus 2", "Slipslide Ride - Bonus 3", "Slipslide Ride (from Bonus 1)", "Slipslide Ride (from Bonus 2)", "Reptile Rumble (from Bonus 2)", "Slipslide Ride - Bonus 1", "Slipslide Ride (from Bonus 3)", "Mine Cart Carnage (warp)", "Stop & Go Station (warp)", "Rope Bridge Rumble (level exit)", "Rope Bridge Rumble (from Save)", "Forest Frenzy (level exit)", "Forest Frenzy (from Save)", "Rambi Bonus", "Winky Bonus", "Forest Frenzy - Bonus 2", "Rope Bridge Rumble - Bonus 1", "Rope Bridge Rumble (from Bonus 2)", "Rope Bridge Rumble - Bonus 2", "Rope Bridge Rumble (from Bonus 1)", "Winky's Walkway (level exit)", "Winky's Walkway (from Save)", "Forest Frenzy (from Bonus 2)", "Forest Frenzy - Bonus 1", "Forest Frenzy (from Bonus 1)", "Clam City (level exit)", "Clam City (from Save)", "Very Gnawty's Lair", "Necky's Nuts", "Really Gnawty Rampage", "Boss Dumb Drum", "Necky's Revenge", "Bumble B Rumble", "Funky", "Funky", "Funky", "Funky", "crash", "crash", "Funky", "Funky", "Cranky", "Cranky", "Cranky", "Cranky", "Cranky", "Cranky", "Funky", "Funky", "Funky", "Funky", "Funky", "Funky", "Candy", "Candy", "Candy", "Candy", "Candy", "Candy" };
        private String[] exitType = new String[] { "World ", "World 1", "World 1", "World 2", "World 1", "World 6", "World 1", "World 2", "World 1", "World 1", "World 6", "World 1", "World 1", "World 3", "World 1", "World 1", "World 2", "World 2", "World 6", "World 4", "World 4", "World 2", "World 1", "World 1", "World 5", "World 1", "World 1", "World 1", "World 1", "World 3", "World 3", "World 3", "World 3", "World ", "World 5", "World 5", "World 4", "World 1", "World 1", "World 5", "World 4", "World 6", "World 5", "World 6", "World 6", "World 6", "World 2", "World 5", "World 6", "World 2", "World 6", "World 6", "Animal Token Room", "World 2", "World 6", "World 6", "World 2", "World 5", "World 6", "World 5", "World 2", "World 6", "World 4", "World 4", "World 5", "World 5", "World 2", "World 3", "World 5", "World 5", "World 1", "World 1", "World 1", "World 6", "World 2", "World 2", "World 1", "World 5", "World 6", "World 2", "World 6", "World 2", "World 3", "World 3", "World 3", "World 2", "World 2", "World 2", "World 2", "World 3", "World 3", "World 3", "World 1", "World 1", "Credits", "World 1", "World 5", "World 5", "World 4", "World 5", "World 5", "World 3", "World 4", "World 4", "Boss", "World 4", "World 4", "World 4", "Expresso", "World 4", "World 1", "World 2", "World 2", "World 3", "World 3", "World 3", "World 3", "World 3", "World 1", "World 1", "World 2", "World 2", "World 6", "World 6", "World 6", "World 5", "World 5", "World 5", "World 6", "World 6", "World 2", "World 2", "World 6", "World 6", "World 6", "World 6", "World 5", "World 5", "World 5", "World 6", "World 5", "World 5", "World 5", "World 5", "World 5", "World 5", "World 5", "World 5", "World 4", "World 4", "World 4", "World 2", "World 6", "World 6", "World 5", "World 5", "World 5", "World 5", "World 5", "World 6", "World 5", "World 5", "World 5", "World 5", "World 3", "World 3", "Enguarde", "World 4", "World 4", "World 3", "World 3", "World 4", "World 4", "World 4", "World 2", "World 2", "World 2", "World 3", "World 3", "World 3", "World 3", "World 3", "World 3", "World 3", "World 3", "World 3", "World 3", "World 3", "World 3", "World 5", "World 5", "World 1", "World 1", "World 4", "World 4", "World 4", "World 4", "World 4", "World 4", "World 4", "World 4", "World 1", "World 4", "World 4", "World 2", "World 2", "World 4", "World 4", "World 3", "World 3", "Rambi ", "Winky", "World 3", "World 4", "World 4", "World 4", "World 4", "World 2", "World 2", "World 3", "World 3", "World 3", "World 3", "World 3", "Boss ", "Boss ", "Boss ", "Boss ", "Boss ", "Boss ", "Funky", "Funky", "Funky", "Funky", "World ", "World ", "Funky", "Funky", "Cranky", "Cranky", "Cranky", "Cranky", "Cranky", "Cranky", "Funky", "Funky", "Funky", "Funky", "Funky", "Funky", "Candy", "Candy", "Candy", "Candy", "Candy", "Candy" };
        private List<String> initialGreetings = new List<String>() { "Well, well, well! You kept an old man waiting for this long. You baboons!", "Who scrambled this poor, poor, island?! This makes my head hurt!", "Donkey, my boy! Come a little closer. I have something to tell you.", "Twenty-three is number one... Oops! Wrong game!", "You don't want to know how long it took me to beat this...", "I had my good friend Sefuroth over and this is what he had to say:", "Careful! One wrong step will land you back in 1-1!", "Have you tried saving your game yet? To do that, visit Candy.", "Have you heard?", "Back in my day, people enjoyed the games they were given." };
        private List<Int32> addressOfGreetings = new List<Int32>() { 0x3c1600, 0x3c1700, 0x3c1800, 0x3c1900, 0x3c1a00, 0x3c1b00 };
        private List<Int32> addressOfHint = new List<Int32>() { 0x3c1000, 0x3c1100, 0x3c1200, 0x3c1300, 0x3c1400, 0x3c1500 };

        // Return a list of strings meeting length requirements
        private List<String> ArrangeStrings(String fullString)
        {
            // Represents valid line length
            int lineLimit = 30;
            List<String> toReturn = new List<String>();
            // All the words of my string
            String[] wordsOfString = fullString.Split(' ');

            // For every word from the string
            for (int i = 0; i < wordsOfString.Length;)
            {
                String currentLine = "";
                while (currentLine.Length < lineLimit && i < wordsOfString.Length)
                {
                    String nextWord = wordsOfString[i];
                    // Will next word make current line too long?
                    if (currentLine.Length + nextWord.Length + 1 >= 30)
                        break;
                    // Add lines
                    currentLine += currentLine == "" ? $"{nextWord}" : $" {nextWord}";
                    i++;
                }
                // Add current line to toReturn
                toReturn.Add(currentLine);
            }

            return toReturn;

        }


        // Select random from list
        private List<String> GetRandomGreeting()
        {
            // Create a list to return
            List<String> toReturn = new List<String>();
            // Loop till we have enough
            while (toReturn.Count < 6)
            {
                // Generate random number in the bounds of the list
                int rand = Global.rng.Next(0, initialGreetings.Count);
                String proposed = initialGreetings[rand];
                // Is proposed in toReturn?
                if (!toReturn.Contains(proposed))
                    toReturn.Add(proposed);
            }
            return toReturn;
        }
        private List<String> GenerateRandomHints()
        {
            List<String> toReturn = new List<String>();
            while (toReturn.Count < 6)
            {
                // Generate random number
                int rand = Global.rng.Next(0, 1000);
                // String to potentially add
                String proposed = "";

                // Assigned proposed based on random number
                if (rand > 800)
                    proposed = TypeHint(rand);
                else /*if (rand > 300)*/
                    proposed = NamedHint(rand);
                /*else
                    proposed = BossLeads(rand);*/
                if (proposed == "")
                    continue;
                // Does our list not have proposed yet?
                if (!toReturn.Contains(proposed))
                    toReturn.Add(proposed);

            }

            return toReturn;
        }
    }
}
