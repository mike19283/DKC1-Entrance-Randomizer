﻿using DKC_Stage_Randomizer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKC_Randomizer_V2._0
{
    class ColorChoice
    {
        private List<Int32> addresses, values;

        public ColorChoice(List<Int32> addresses, List<Int32> values)
        {
            this.addresses = addresses;
            this.values = values;
        }
        public void Apply()
        {
            Global.copyAllBytes(addresses, values);
        }
    }
}