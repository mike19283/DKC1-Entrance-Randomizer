﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DKC_Entrance_Randomizer
{
    class SpoilerLog
    {

        public List<String> pathTakenString = new List<String>();
        public byte current;

        public SpoilerLog(List<String> pathTakenString, byte current)
        {
            this.pathTakenString.AddRange(pathTakenString);
            this.current = current;
        }
    }
}
