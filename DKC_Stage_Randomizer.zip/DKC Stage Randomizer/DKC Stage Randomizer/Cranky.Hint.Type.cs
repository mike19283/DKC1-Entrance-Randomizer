﻿using DKC_Stage_Randomizer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DKC_Entrance_Randomizer
{
    public partial class Cranky
    {
        // Styles of hints

        // Type == world num versus cranky
        private String TypeHint(int rand)
        {
            // boss: [name, type]
            // String
            String toReturn = "";
            String currentType = bossList[rand % 5][1];
            // What type of hint did we roll?
            if (currentType.Contains("World"))
            {
                //Two possibilities for this
                if (rand % 4 == 0)
                    toReturn = $"Knowledge I could pass on is that {currentType} has a boss in it.";
                else if (rand % 4 == 1)
                    toReturn = $"Word is {currentType} has a boss in it.";
                else if (rand % 4 == 2)
                    toReturn = $"You should probably pay a visit to {currentType}.";
                else
                    toReturn = $"The Kremling I have \"befriended\" told me a boss is in {currentType}";

            }
            else
            {
                if (rand % 2 == 0)
                    toReturn = $"Word around the grapevine is a visit to {currentType} is beneficial.";
                else
                    toReturn = $"The Kremling I have \"befriended\" told me a boss is after {currentType}";
            }
            return toReturn;
        }
        private String NamedHint(int rand)
        {
            // boss: [name, type]
            // String
            String toReturn = "";
            String currentName = bossList[rand % 5][0];
            // Choose a random boss
            byte randomBoss = new byte[] { 0xe0, 0xe1, 0xe3, 0xe5, 0x68 }[Global.rng.Next(0, 5)];
            // Get an array representing path
            String[] shortestPath = new Entrance(0, 0).GenerateSpoilerString(randomBoss).Split(',');
            if (shortestPath.Length <= 3)
                return "";
            // Choose a random stage from the path
            currentName = shortestPath[Global.rng.Next(2, shortestPath.Length - 1)];
            // Get only the base name
            currentName = Regex.Split(currentName, "(?:\\s\\-\\s)|(?:\\s\\()")[0];
            if (rand % 4 == 0)
                toReturn = $"I once heard that a visit to {currentName} would pay off";
            else if (rand % 4 == 1)
            {
                toReturn = $"Have you noticed? You can see K Rool's ship from {Regex.Split(boss68[0], "(?:\\s\\-\\s)|(?:\\s\\()")[0]}.";
            }
            else if (rand % 4 == 2)
            {
                toReturn = $"{currentName} is on the way of the hero.";
            }
            else
                toReturn = $"If you see {currentName}, you are going the right way.";
        return toReturn;
        }
        // Leads
        private String BossLeads(int rand)
        {
            // boss: [name, type]
            // String
            String toReturn = "";
            if (true)/*(rand % 2 == 0)*/
                toReturn = $"{bonusLeads} {(bonusLeads == 1 ? "boss is found in a bonus." : "bosses are found in bonuses.")}";
            else
                toReturn = $"I overheard that {exitLeads} {(exitLeads == 1 ? "boss" : "bosses")} can be found at the end of {(exitLeads == 1 ? "a level" : "levels")}";
            return toReturn;
        }

    }
}
